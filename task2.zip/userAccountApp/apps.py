from django.apps import AppConfig


class UseraccountappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'userAccountApp'
    verbose_name = 'بخش کاربران'
