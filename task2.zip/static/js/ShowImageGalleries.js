function showLargeImage(imgSrc){
    $('#mainImage').attr('src',imgSrc);
}