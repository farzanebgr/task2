from rest_framework.routers import DefaultRouter
from django.urls import path, include
from userPanelApp.api import views

urlpatterns = [
    path('user-panel/', views.UserPanelDashboardGL.as_view(), name='user-panel'),
    path('user-panel/<int:id>/', views.UserPanelDashboardGCRUD.as_view(), name='user-panel-change'),
    path('edit-profile/', views.ChangeProfileGRU.as_view(), name='edit-profile'),
    path('change-password/', views.ChangePasswordGRU.as_view(), name='change-password'),
    path('user-basket/', views.UserBasketGLR.as_view(), name='user-basket'),
    path('user-basket/<int:pk>/', views.UserBasketGUD.as_view(), name='user-basket'),
    path('my-shopping/', views.MyShoppingDetailGL.as_view(), name='user-shopping'),
    path('my-shopping/<int:order_id>/', views.MyShoppingDetailGR.as_view(), name='user-shopping-detail'),
    # path('remove-order-detail/', views.remove_order_detail, name='remove-order-detail-ajax'),
    # path('change-order-detail/', views.change_order_detail_count, name='change-order-detail-count-ajax'),
    # path('shopping-paid/', views.shoppingPaid, name='shopping-paid-ajax'),

]
