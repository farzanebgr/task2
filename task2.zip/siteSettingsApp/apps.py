from django.apps import AppConfig


class SitesettingsappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'siteSettingsApp'
    verbose_name = 'بخش تنظیمات سایت'
